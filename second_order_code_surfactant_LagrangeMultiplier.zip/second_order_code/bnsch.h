void initialization(double **c, double **ro);

void augmenc(double **c, int nxt, int nyt);

void cahn_ro1(double **oro, double **oc,  double **ro1);

void cahn_ro2(double **oro, double **ro2);

void source_ro1(double **oro, double **oc, double **src_c, double **src_mu);

void source_ro2(double **oro, double **src_c, double **src_mu);

void s_vcycle(double **uf_new,  double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel);

void s_relax(double **c_new, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt);

void s_defect(double **duc, double **dwc, double **uf_new, double **wf_new,
            double **suf, double **swf, int nxf, int nyf);

void s_nonL(double **ru, double **rw, double **c_new, double **mu_new, int nxt, int nyt);


void cahn_c1(double **c_old, double **ro, double **c1);

void cahn_c2(double **c_old, double **ro, double **c2);

void source_c1(double **c_old, double **ro, double **src_c, double **src_mu, double **src_ka);

void source_c2(double **c_old, double **ro, double **src_c, double **src_mu, double **src_ka);

void laplace_ch(double **a, double **lap_a, int nxt, int nyt);

void vcycle(double **uf_new, double **ro, double **wf_new, double **kf_new, double **su, double **sw, double **sk, int nxf, int nyf, int ilevel);

void relax(double **c_new, double **ro, double **mu_new, double **ka_new, double **su, double **sw, double **sk, int ilevel, int nxt, int nyt);

void defect(double **duc, double **dwc, double **dkc, double **ro, double **uf_new, double **wf_new, double **kf_new,
            double **suf, double **swf, double **skf, int nxf, int nyf);

void nonL(double **ru, double **rw, double **rk, double **ro, double **c_new, double **mu_new, double **ka_new, int nxt, int nyt);

void restrict2(double **uf, double **uc, double **vf, double **vc, int nxt, int nyt);

void restrict3(double **uf, double **uc, double **vf, double **vc, double **wf, double **wc, int nxt, int nyt);

void restrict1(double **vf, double **vc, int nxt, int nyt);

void prolong_ch(double **uc, double **uf, double **vc, double **vf, int nxt, int nyt);

void prolong_ch3(double **uc, double **uf, double **vc, double **vf, double **wc, double **wf, int nxt, int nyt);


double error(double **c_old, double **c_new, int nxt, int nyt);

double update_q(double **oc, double **c1, double **c2, int nxt, int nyt);

double update_r(double **oc, double **c1, double **c2, int nxt, int nyt);
