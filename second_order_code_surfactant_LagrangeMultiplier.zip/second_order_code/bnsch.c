/************************************************

   Binary NSCH
   with variable density and variable viscosity

************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "util.h"
#include "bnsch.h"
#define NR_END 1

int nx, ny, n_level,  c_relax, count;
double pi, xleft, xright, yleft, yright, h, dt, gam, Cahn,  M1, M2,
        **worku, **workv, **workp, alpha, beta, theta, eta, ros, **mc,  q, r, **ka1, **ka2,
       **ct, **sc, **sro, **smu, **ska, **mu1, **mu2, **srmu, **rmu1, **rmu2;
char bufferc[100], bufferro[100];
int main()
{
    extern int nx, ny, n_level,  c_relax, count;
    extern double pi, xleft, xright, yleft, yright, h, dt, gam, Cahn,  M1,  M2,
                  **worku, **workv, **workp, alpha, beta, theta, eta, ros, **mc, q, r, **ka1, **ka2,
                  **ct, **sc, **sro, **smu, **ska, **mu1, **mu2, **srmu, **rmu1, **rmu2;

    extern char  bufferc[100], bufferro[100];
    int i,j, it, max_it, ns;
    double **oc, **c1, **c2, **nc, **oro, **ro1, **ro2, **nro;
    
    FILE  *fc, *fro;
    
    
    /*****/
     
    nx = gnx;
    ny = gny;
    n_level = (int)(log(nx)/log(2)-0.9);
    
    c_relax = 5;
    
    pi = 4.0*atan(1.0);
    
    xleft = 0.0, xright = 2.0*pi;
    yleft = 0.0, yright = xright*(double)ny/(double)nx;
    
    count = 0;
    
    /***********************/
    
    h = xright/(double)nx;

    M1 = 0.00025;
    M2 = 0.00025;
    alpha = 0.00025;
    beta = 1.0;
    theta = 0.3;

    ros = 1.0;  //bulk concentration of surfactant

   dt = 0.01*h*h;

    gam = 0.05;
    Cahn = pow(gam,2);

    eta = 0.08;
    
    max_it = 3200;
    ns = max_it/5;

     q = 1.0;
    
     r = 1.0;

    /***********************/
    
    printf("nx = %d, ny = %d\n", nx, ny);
    printf("n_level = %d\n", n_level);
    printf("dt      = %f\n", dt);
    printf("max_it  = %d\n", max_it);
    printf("ns      = %d\n", ns);
  
    c1 = dmatrix(0, nx+1, 0, ny+1);
    c2= dmatrix(0, nx+1, 0, ny+1);
    oc = dmatrix(0, nx+1, 0, ny+1);
    nc = dmatrix(0, nx+1, 0, ny+1);

    ro1 = dmatrix(0, nx+1, 0, ny+1);
    ro2 = dmatrix(0, nx+1, 0, ny+1);
    oro = dmatrix(0, nx+1, 0, ny+1);
    nro = dmatrix(0, nx+1, 0, ny+1);
  
    worku = dmatrix(0, nx, 1, ny);
    workv = dmatrix(1, nx, 0, ny);
    workp = dmatrix(1, nx, 1, ny);
   
    ct = dmatrix(1, nx, 1, ny);
    sc = dmatrix(1, nx, 1, ny);
    sro = dmatrix(1, nx, 1, ny);
    smu = dmatrix(1, nx, 1, ny);
    ska = dmatrix(1, nx, 1, ny);
    mu1 = dmatrix(1, nx, 1, ny);
    mu2 = dmatrix(1, nx, 1, ny);
    ka1 = dmatrix(1, nx, 1, ny);
    ka2 = dmatrix(1, nx, 1, ny);
   
    srmu = dmatrix(1, nx, 1, ny);
    rmu1 = dmatrix(1, nx, 1, ny);
    rmu2 = dmatrix(1, nx, 1, ny);
       
    zero_matrix(rmu1, 1, nx, 1, ny); 
    zero_matrix(mu1, 1, nx, 1, ny); 
    zero_matrix(ka1, 1, nx, 1, ny); 
    zero_matrix(rmu2, 1, nx, 1, ny); 
    zero_matrix(mu2, 1, nx, 1, ny); 
    zero_matrix(ka2, 1, nx, 1, ny); 
 
    sprintf(bufferc,"data2/datac.m");
    sprintf(bufferro,"data2/dataro.m");
   
    fc = fopen(bufferc,"w");
    fro = fopen(bufferro,"w");
  
    fclose(fc);
    fclose(fro);
    
    initialization(oc, oro);
    
    print_data(oc, oro);
    
    for (it=1; it<=max_it; it++) {

    //calculate ro1
          cahn_ro1(oro, oc, ro1);

    //calculate ro2
          cahn_ro2(oro, ro2);

    //calculate q
         update_q(oro,ro1,ro2,nx,ny);
    
     //update nro
     ijloop{  nro[i][j] = ro1[i][j] + q*ro2[i][j];  }


   //calculate c1
          cahn_c1(oc, nro, c1);

   //calculate c2
          cahn_c2(oc, nro, c2);

   //calculate r
         update_r(oc,c1,c2,nx,ny);

   //update nc
     ijloop{  nc[i][j] = c1[i][j] + r*c2[i][j];  }

    
        mat_copy(oc, nc, 1, nx, 1, ny);
        mat_copy(oro, nro, 1, nx, 1, ny);
        
        printf("it = %d\n", it);
        
        if (it % ns == 0) {
            count++;
            print_data(nc,nro);
            printf("print out counts %d\n", count);
        }
    }
    
    return 0;
}

void initialization(double **c, double **ro)
{
    extern double xright, yright, h, gam, pi;
    
    int i, j;
    double x, y;
    
    ijloop {
        x = ((double)i-0.5)*h;
        y = ((double)j-0.5)*h;
        
  //    c[i][j] =  0.001*(2.0*rand()/(float)RAND_MAX - 1.0);
   
  //    ro[i][j] = 0.2 + 0.001*(2.0*rand()/(float)RAND_MAX - 1.0);
  

 c[i][j] = tanh( ( 0.4*pi - sqrt(pow(x-0.6*pi,2) + pow(y-pi,2)) )/(sqrt(2.0)*gam) ) 
          + tanh( ( 0.4*pi - sqrt(pow(x-1.4*pi,2) + pow(y-pi,2)) )/(sqrt(2.0)*gam) )  + 1.0;
  
  ro[i][j] = 0.02*(1.0-fabs(c[i][j]));
  
  c[i][j] = 0.3*cos(3.0*x) + 0.5*cos(y);
  ro[i][j] = 0.2*sin(2*x) + 0.25*sin(y);

        
    }
    
     
}



void augmenc(double **c, int nxt, int nyt)
{
    int i, j;
    
    for (j=1; j<=nyt; j++) { 
        c[0][j] = c[nxt][j];
        c[nxt+1][j] = c[1][j];
    }
    
    for (i=0; i<=nxt+1; i++) { 
        c[i][0] = c[i][nyt];
        c[i][nyt+1] = c[i][1];
    }
    
}


void cahn_ro1(double **oro, double **oc,  double **ro1)
{
    extern int nx, ny;
    extern double **ct, **sro, **srmu, **rmu1;
    
    int i,j, it_mg = 1, max_it_CH = 200;
    double resid = 1.0, tol = 1.0e-6;
    
    mat_copy(ct, oro, 1, nx, 1, ny);
    
    source_ro1(oro, oc, sro, srmu);
     
    while (it_mg <= max_it_CH && resid > tol) {
        
        s_vcycle(ro1, rmu1, sro, srmu, nx ,ny, 1);
        resid = error(ct, ro1, nx, ny);
        mat_copy(ct, ro1, 1, nx, 1, ny);
        
        it_mg++;
    }

    printf("surfactant ro1 %16.14f   %d\n", resid, it_mg-1);
}


void cahn_ro2(double **oro, double **ro2)
{
    extern int nx, ny;
    extern double **ct, **sro, **srmu, **rmu2;
    
    int i,j, it_mg = 1, max_it_CH = 200;
    double resid = 1.0, tol = 1.0e-6;
    
    mat_copy(ct, oro, 1, nx, 1, ny);
    
    source_ro2(oro, sro, srmu);
     
    while (it_mg <= max_it_CH && resid > tol) {
        
        s_vcycle(ro2, rmu2, sro, srmu, nx ,ny, 1);
        resid = error(ct, ro2, nx, ny);
        mat_copy(ct, ro2, 1, nx, 1, ny);
        
        it_mg++;
    }

    printf("surfactant ro2 %16.14f   %d\n", resid, it_mg-1);
}


void source_ro1(double **oro, double **oc, double **src_c, double **src_mu)
{
    extern int nx, ny;
    extern double dt, h, theta;
    
    int i, j;
     double **gadx, **gady;
     
     gadx = dmatrix(1, nx, 1, ny);
     gady = dmatrix(1, nx, 1, ny);
     

    augmenc(oc, nx, ny);

   ijloop{  gadx[i][j] = ( oc[i+1][j] - oc[i-1][j] )/(2.0*h);  }
   
   ijloop{  gady[i][j] = ( oc[i][j+1] - oc[i][j-1] )/(2.0*h);  }
   

    ijloop {
        src_c[i][j] = oro[i][j]/dt;
        
        src_mu[i][j] = - theta*( pow( gadx[i][j], 2) + pow(gady[i][j],2)  ); 
    }
    
   
       free_dmatrix(gadx, 1, nx, 1, ny);
       free_dmatrix(gady, 1, nx, 1, ny);
}


void source_ro2(double **oro, double **src_c, double **src_mu)
{
    extern int nx, ny;
    extern double dt, h, ros, eta;
    
    int i, j;

    ijloop {
        src_c[i][j] = 0.0;
        
        src_mu[i][j] = oro[i][j]*(oro[i][j]-ros)*(oro[i][j]-0.5*ros)/(eta*eta);
    }
    

}


void s_vcycle(double **uf_new,  double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel)
{
    extern int n_level;
    
    s_relax(uf_new, wf_new, su, sw, ilevel, nxf, nyf);
   
   if (ilevel < n_level) {
        
        int nxc, nyc;
        double **uc_new, **wc_new, **duc, **dwc, 
               **uc_def, **wc_def, **uf_def, **wf_def;
        
        nxc = nxf/2, nyc = nyf/2;
        
        uc_new = dmatrix(1, nxc, 1, nyc);
        wc_new = dmatrix(1, nxc, 1, nyc);
        duc = dmatrix(1, nxc, 1, nyc);
        dwc = dmatrix(1, nxc, 1, nyc);
        uc_def = dmatrix(1, nxc, 1, nyc);
        wc_def = dmatrix(1, nxc, 1, nyc);
        uf_def = dmatrix(1, nxf, 1, nyf);
        wf_def = dmatrix(1, nxf, 1, nyf);

        s_defect(duc, dwc, uf_new, wf_new, su, sw, nxf, nyf);

          zero_matrix(uc_def, 1, nxc, 1, nyc);
          zero_matrix(wc_def, 1, nxc, 1, nyc);
        
        s_vcycle(uc_def,  wc_def, duc, dwc, nxc, nyc, ilevel+1);
        
        prolong_ch(uc_def, uf_def, wc_def, wf_def, nxc, nyc);
        
        mat_add2(uf_new, uf_new, uf_def, wf_new, wf_new, wf_def, 1, nxf, 1, nyf);
        
        s_relax(uf_new, wf_new, su, sw, ilevel, nxf, nyf);
        
        free_dmatrix(uc_new, 1, nxc, 1, nyc);
        free_dmatrix(wc_new, 1, nxc, 1, nyc);
        free_dmatrix(duc, 1, nxc, 1, nyc);
        free_dmatrix(dwc, 1, nxc, 1, nyc);
        free_dmatrix(uc_def, 1, nxc, 1, nyc);
        free_dmatrix(wc_def, 1, nxc, 1, nyc);
        free_dmatrix(uf_def, 1, nxf, 1, nyf);
        free_dmatrix(wf_def, 1, nxf, 1, nyf);
    }
   
}

void s_relax(double **c_new, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt)
{
    extern int c_relax;
    extern double xright, dt, beta, M2;
    
    int i, j, iter;
    double ht2, a[4], f[2], det;
    
    ht2 = pow(xright/(double)nxt,2);
    
    for (iter=1; iter<=c_relax; iter++) {
        
        ijloopt {
            a[0] = 1.0/dt;
            
            a[1] = 4.0*M2/ht2;
                  
            a[2] = -4.0*beta/ht2;
         
            a[3] = 1.0;
            
            f[0] = su[i][j];
            if (i > 1)   f[0] += M2*mu_new[i-1][j]/ht2;
            else         f[0] += M2*mu_new[nxt][j]/ht2;
            
            if (i < nxt) f[0] += M2*mu_new[i+1][j]/ht2;
            else         f[0] += M2*mu_new[1][j]/ht2;
            
           if (j > 1)   f[0] += M2*mu_new[i][j-1]/ht2;
            else         f[0] += M2*mu_new[i][nyt]/ht2;
            
            if (j < nyt) f[0] += M2*mu_new[i][j+1]/ht2;
            else         f[0] += M2*mu_new[i][1]/ht2;
            
            f[1] = sw[i][j];
             if (i > 1)   f[1] += -beta*c_new[i-1][j]/ht2;
            else         f[1] += -beta*c_new[nxt][j]/ht2;
            
            if (i < nxt) f[1] += -beta*c_new[i+1][j]/ht2;
            else         f[1] += -beta*c_new[1][j]/ht2;
            
           if (j > 1)   f[1] += -beta*c_new[i][j-1]/ht2;
            else         f[1] += -beta*c_new[i][nyt]/ht2;
            
            if (j < nyt) f[1] += -beta*c_new[i][j+1]/ht2;
            else         f[1] += -beta*c_new[i][1]/ht2;
            
            det = a[0]*a[3] - a[1]*a[2];
            
            c_new[i][j] = (a[3]*f[0] - a[1]*f[1])/det;
            mu_new[i][j] = (-a[2]*f[0] + a[0]*f[1])/det;
        }
    }
    
}


void s_defect(double **duc, double **dwc, double **uf_new, double **wf_new,
            double **suf, double **swf, int nxf, int nyf)
{
    double **ruf, **rwf,  **rruf, **rrwf;
    
    ruf = dmatrix(1, nxf, 1, nyf);
    rwf = dmatrix(1, nxf, 1, nyf);
    rruf = dmatrix(1, nxf/2, 1, nyf/2);
    rrwf = dmatrix(1, nxf/2, 1, nyf/2);
        
    s_nonL(ruf, rwf, uf_new, wf_new, nxf, nyf);
 
    mat_sub2(ruf, suf, ruf, rwf, swf, rwf, 1, nxf, 1, nyf);
    
    restrict2(ruf, duc, rwf, dwc, nxf/2, nyf/2);
    
    free_dmatrix(ruf, 1, nxf, 1, nyf);
    free_dmatrix(rwf, 1, nxf, 1, nyf);
    free_dmatrix(rruf, 1, nxf/2, 1, nyf/2);
    free_dmatrix(rrwf, 1, nxf/2, 1, nyf/2);
}



void s_nonL(double **ru, double **rw, double **c_new, double **mu_new, int nxt, int nyt)
{
    extern double dt, M2, beta;
    
    int i, j;
    double **lap_mu, **lap_c;
    
    lap_mu = dmatrix(1, nxt, 1, nyt);
    lap_c = dmatrix(1, nxt, 1, nyt);
    
     laplace_ch(mu_new, lap_mu, nxt, nyt);
     laplace_ch(c_new, lap_c, nxt, nyt);
    
    ijloopt {
        ru[i][j] = 1.0*c_new[i][j]/dt - M2*lap_mu[i][j]; 
        rw[i][j] = mu_new[i][j] + beta*lap_c[i][j];
    }
    
    free_dmatrix(lap_mu, 1, nxt, 1, nyt);
    free_dmatrix(lap_c, 1, nxt, 1, nyt);
  
}


/********************* phase field part ***********************/


void cahn_c1(double **c_old, double **ro, double **c1)
{
    extern int nx, ny;
    extern double **ct, **sc, **smu, **ska, **mu1, **ka1;
    
    int it_mg = 1, max_it_CH = 200;
    double resid = 1.0, tol = 1.0e-6;
    
    mat_copy(ct, c_old, 1, nx, 1, ny);
    
    source_c1(c_old, ro, sc, smu,ska);
    
    while (it_mg <= max_it_CH && resid > tol) {
        
        vcycle(c1, ro, mu1, ka1, sc, smu, ska, nx ,ny, 1);
        resid = error(ct, c1, nx, ny);
        mat_copy(ct, c1, 1, nx, 1, ny);
        
        it_mg++;
    }

    printf("cahn c1 %16.14f   %d\n", resid, it_mg-1);
}


void cahn_c2(double **c_old, double **ro, double **c2)
{
    extern int nx, ny;
    extern double **ct, **sc, **smu, **ska, **mu2, **ka2;
    
    int it_mg = 1, max_it_CH = 200;
    double resid = 1.0, tol = 1.0e-6;
    
    mat_copy(ct, c_old, 1, nx, 1, ny);
    
    source_c2(c_old, ro, sc, smu,ska);
    
    while (it_mg <= max_it_CH && resid > tol) {
        
        vcycle(c2, ro, mu2, ka2, sc, smu, ska, nx ,ny, 1);
        resid = error(ct, c2, nx, ny);
        mat_copy(ct, c2, 1, nx, 1, ny);
        
        it_mg++;
    }

    printf("cahn c2 %16.14f   %d\n", resid, it_mg-1);
}

void source_c1(double **c_old, double **ro, double **src_c, double **src_mu, double **src_ka)
{
    extern int nx, ny;
    extern double dt, h, gam, theta;
    
    int i, j;
    double a1, a2, a3, a4;
        
    augmenc(c_old, nx, ny);
    augmenc(ro, nx, ny);

    ijloop {

     a1 = 0.5*( ro[i+1][j] + ro[i][j] );
     a2 = 0.5*( ro[i][j] + ro[i-1][j] );
     a3 = 0.5*( ro[i][j+1] + ro[i][j] );
     a4 = 0.5*( ro[i][j] + ro[i][j-1] );

        src_c[i][j] = c_old[i][j]/dt;
        
        src_mu[i][j] = theta*( a1*c_old[i+1][j] + a2*c_old[i-1][j] + a3*c_old[i][j+1] + a4*c_old[i][j-1]
                             -  (a1+a2+a3+a4)*c_old[i][j] )/(h*h);

       src_ka[i][j] = 0.0;

    }
       
}


void source_c2(double **c_old, double **ro, double **src_c, double **src_mu, double **src_ka)
{
    extern int nx, ny;
    extern double dt, h, gam, theta;
    
    int i, j;

    ijloop {

        src_c[i][j] = 0.0;
        
        src_mu[i][j] = ( pow(c_old[i][j],3) - c_old[i][j] )/(gam*gam);

       src_ka[i][j] = 0.0;

    }
       
}


void laplace_ch(double **a, double **lap_a, int nxt, int nyt)
{
    extern double xright;
    
    int i, j;
    double ht2, dadx_L, dadx_R, dady_B, dady_T;
    
    ht2 = pow(xright/(double)nxt,2);
    
    ijloopt {
        
        if (i > 1)
            dadx_L = a[i][j] - a[i-1][j];
        else
            dadx_L = a[i][j] - a[nxt][j];
        
        if (i < nxt)
            dadx_R = a[i+1][j] - a[i][j];
        else
            dadx_R = a[1][j] - a[i][j];
        
        if (j > 1)
            dady_B = a[i][j] - a[i][j-1];
        else
            dady_B = a[i][j] - a[i][nyt];
        
        if (j < nyt)
            dady_T = a[i][j+1] - a[i][j];
        else
            dady_T = a[i][1] - a[i][j];
        
        lap_a[i][j] = (dadx_R - dadx_L + dady_T - dady_B)/ht2;
    }
    
}

void vcycle(double **uf_new, double **ro, double **wf_new, double **kf_new, double **su, double **sw, double **sk, int nxf, int nyf, int ilevel)
{
    extern int n_level;
    
    relax(uf_new, ro, wf_new, kf_new, su, sw, sk, ilevel, nxf, nyf);
    
   if (ilevel < n_level) {
        
        int nxc, nyc;
        double **uc_new, **wc_new, **kc_new, **duc, **dwc, **dkc, **uc_old,
               **uc_def, **wc_def, **kc_def, **uf_def, **wf_def, **kf_def;
        
        nxc = nxf/2, nyc = nyf/2;
        
        uc_new = dmatrix(1, nxc, 1, nyc);
        wc_new = dmatrix(1, nxc, 1, nyc);
        kc_new = dmatrix(1, nxc, 1, nyc);
        duc = dmatrix(1, nxc, 1, nyc);
        dwc = dmatrix(1, nxc, 1, nyc);
        dkc = dmatrix(1, nxc, 1, nyc);
        uc_old = dmatrix(0, nxc+1, 0, nyc+1);
        uc_def = dmatrix(1, nxc, 1, nyc);
        wc_def = dmatrix(1, nxc, 1, nyc);
        kc_def = dmatrix(1, nxc, 1, nyc);
        uf_def = dmatrix(1, nxf, 1, nyf);
        wf_def = dmatrix(1, nxf, 1, nyf); 
        kf_def = dmatrix(1, nxf, 1, nyf); 

        defect(duc, dwc, dkc, ro, uf_new, wf_new, kf_new, su, sw, sk, nxf, nyf);
        
        restrict1(ro, uc_old, nxc, nyc);
        
        augmenc(uc_old, nxc, nyc);

          zero_matrix(uc_def, 1, nxc, 1, nyc);
          zero_matrix(wc_def, 1, nxc, 1, nyc);
          zero_matrix(kc_def, 1, nxc, 1, nyc);
        
        vcycle(uc_def, uc_old, wc_def, kc_def, duc, dwc, dkc, nxc, nyc, ilevel+1);
        
        prolong_ch3(uc_def, uf_def, wc_def, wf_def, kc_def, kf_def, nxc, nyc);
        
        mat_add3(uf_new, uf_new, uf_def, wf_new, wf_new, wf_def, kf_new, kf_new, kf_def, 1, nxf, 1, nyf);
        
        relax(uf_new, ro, wf_new, kf_new, su, sw, sk, ilevel, nxf, nyf);
        
        free_dmatrix(uc_new, 1, nxc, 1, nyc);
        free_dmatrix(wc_new, 1, nxc, 1, nyc);
        free_dmatrix(kc_new, 1, nxc, 1, nyc);
        free_dmatrix(duc, 1, nxc, 1, nyc);
        free_dmatrix(dwc, 1, nxc, 1, nyc);
        free_dmatrix(dkc, 1, nxc, 1, nyc);
        free_dmatrix(uc_old, 0, nxc+1, 0, nyc+1);
        free_dmatrix(uc_def, 1, nxc, 1, nyc);
        free_dmatrix(wc_def, 1, nxc, 1, nyc);
        free_dmatrix(kc_def, 1, nxc, 1, nyc);
        free_dmatrix(uf_def, 1, nxf, 1, nyf);
        free_dmatrix(wf_def, 1, nxf, 1, nyf);
        free_dmatrix(kf_def, 1, nxf, 1, nyf);
    }
   
}

void relax(double **c_new, double **ro, double **mu_new, double **ka_new, double **su, double **sw, double **sk, int ilevel, int nxt, int nyt)
{
    extern int c_relax;
    extern double xright, dt, M1, alpha, gam, theta;
    
    int i, j, iter;
    double ht2, a[9], f[3], det, a1, a2, a3, a4;
    
    ht2 = pow(xright/(double)nxt,2);

     augmenc(ro, nxt, nyt);
    
    for (iter=1; iter<=c_relax; iter++) {
        
        ijloopt {

           a1 = 0.5*( ro[i+1][j] + ro[i][j] );
           a2 = 0.5*( ro[i][j] + ro[i-1][j] );
           a3 = 0.5*( ro[i][j+1] + ro[i][j] );
           a4 = 0.5*( ro[i][j] + ro[i][j-1] );
 
            a[0] = 1.0/dt;
            
            a[1] = 4.0*M1/ht2;

            a[2] = 0.0;
                   
            a[3] = -4.0/ht2 + theta*(a1 + a2 + a3 + a4)/ht2;
         
            a[4] = 1.0;

            a[5] = 4.0*alpha/ht2;

            a[6] = 4.0/ht2;

            a[7] = 0.0;

            a[8] = 1.0;

          
            f[0] = su[i][j];
            if (i > 1)   f[0] += M1*mu_new[i-1][j]/ht2;
            else         f[0] += M1*mu_new[nxt][j]/ht2;
            
            if (i < nxt) f[0] += M1*mu_new[i+1][j]/ht2;
            else         f[0] += M1*mu_new[1][j]/ht2;
            
           if (j > 1)   f[0] += M1*mu_new[i][j-1]/ht2;
            else         f[0] += M1*mu_new[i][nyt]/ht2;
            
            if (j < nyt) f[0] += M1*mu_new[i][j+1]/ht2;
            else         f[0] += M1*mu_new[i][1]/ht2;
            
            f[1] = sw[i][j];
            if (i > 1)   f[1] += -c_new[i-1][j]/ht2 + alpha*ka_new[i-1][j]/ht2 + theta*a2*c_new[i-1][j]/ht2;
            else         f[1] += -c_new[nxt][j]/ht2 + alpha*ka_new[nxt][j]/ht2 + theta*a2*c_new[nxt][j]/ht2;
            
            if (i < nxt) f[1] += -c_new[i+1][j]/ht2 + alpha*ka_new[i+1][j]/ht2 + theta*a1*c_new[i+1][j]/ht2;
            else         f[1] += -c_new[1][j]/ht2 + alpha*ka_new[1][j]/ht2 + theta*a1*c_new[1][j]/ht2;
            
            if (j > 1)   f[1] += -c_new[i][j-1]/ht2 + alpha*ka_new[i][j-1]/ht2 + theta*a4*c_new[i][j-1]/ht2;
            else         f[1] += -c_new[i][nyt]/ht2 + alpha*ka_new[i][nyt]/ht2 + theta*a4*c_new[i][nyt]/ht2;
            
            if (j < nyt) f[1] += -c_new[i][j+1]/ht2 + alpha*ka_new[i][j+1]/ht2  + theta*a3*c_new[i][j+1]/ht2;
            else         f[1] += -c_new[i][1]/ht2 + alpha*ka_new[i][1]/ht2 + theta*a3*c_new[i][1]/ht2;

           f[2] = sk[i][j];
            if (i > 1)   f[2] += c_new[i-1][j]/ht2;
            else         f[2] += c_new[nxt][j]/ht2;
            
            if (i < nxt) f[2] += c_new[i+1][j]/ht2;
            else         f[2] += c_new[1][j]/ht2;
            
           if (j > 1)   f[2] += c_new[i][j-1]/ht2;
            else         f[2] += c_new[i][nyt]/ht2;
            
            if (j < nyt) f[2] += c_new[i][j+1]/ht2;
            else         f[2] += c_new[i][1]/ht2;
          
            
            det = a[0]*a[4]*a[8] + a[3]*a[7]*a[2] + a[6]*a[5]*a[1] - a[2]*a[4]*a[6] - a[1]*a[3]*a[8] - a[0]*a[7]*a[5];
            
            c_new[i][j] = ( (a[4]*a[8]-a[5]*a[7])*f[0] - (a[1]*a[8]-a[2]*a[7])*f[1] + (a[1]*a[5]-a[2]*a[4])*f[2] )/det;
            mu_new[i][j] = ( -(a[3]*a[8]-a[5]*a[6])*f[0] + (a[0]*a[8]-a[2]*a[6])*f[1] - (a[0]*a[5]-a[2]*a[3])*f[2] )/det;
            ka_new[i][j] = ( (a[3]*a[7]-a[4]*a[6])*f[0] - (a[0]*a[7]-a[1]*a[6])*f[1] + (a[0]*a[4]-a[1]*a[3])*f[2] )/det;

        }
    }
    
}

void defect(double **duc, double **dwc, double **dkc, double **ro, double **uf_new, double **wf_new, double **kf_new,
            double **suf, double **swf, double **skf, int nxf, int nyf)
{
    double **ruf, **rwf, **rkf, **rruf, **rrwf, **rrkf;
    
    ruf = dmatrix(1, nxf, 1, nyf);
    rwf = dmatrix(1, nxf, 1, nyf);
    rkf = dmatrix(1, nxf, 1, nyf);
    rruf = dmatrix(1, nxf/2, 1, nyf/2);
    rrwf = dmatrix(1, nxf/2, 1, nyf/2);
    rrkf = dmatrix(1, nxf/2, 1, nyf/2);
        
    nonL(ruf, rwf, rkf, ro, uf_new, wf_new, kf_new, nxf, nyf);
    
    mat_sub3(ruf, suf, ruf, rwf, swf, rwf, rkf, skf, rkf, 1, nxf, 1, nyf);
    
    restrict3(ruf, duc, rwf, dwc, rkf, dkc, nxf/2, nyf/2);
    
    free_dmatrix(ruf, 1, nxf, 1, nyf);
    free_dmatrix(rwf, 1, nxf, 1, nyf);
    free_dmatrix(rkf, 1, nxf, 1, nyf);
    free_dmatrix(rruf, 1, nxf/2, 1, nyf/2);
    free_dmatrix(rrwf, 1, nxf/2, 1, nyf/2);
    free_dmatrix(rrkf, 1, nxf/2, 1, nyf/2);
}

void nonL(double **ru, double **rw, double **rk, double **ro, double **c_new, double **mu_new, double **ka_new, int nxt, int nyt)
{
    extern double xright, dt, M1, gam,  alpha, theta;
    
    int i, j;
    double ss, ht2, **lap_c, **lap_mu, **lap_ka, a1, a2, a3, a4;
    
    lap_c = dmatrix(1, nxt, 1, nyt);
    lap_mu = dmatrix(1, nxt, 1, nyt);
    lap_ka = dmatrix(1, nxt, 1, nyt);
    
     laplace_ch(c_new, lap_c, nxt, nyt);
     laplace_ch(mu_new, lap_mu, nxt, nyt);
     laplace_ch(ka_new, lap_ka, nxt, nyt);

     ht2 = pow(xright/(double)nxt,2);

      augmenc(ro, nxt, nyt);
    
    ijloopt {


        ss = 0.0;

           a1 = 0.5*( ro[i+1][j] + ro[i][j] );
           a2 = 0.5*( ro[i][j] + ro[i-1][j] );
           a3 = 0.5*( ro[i][j+1] + ro[i][j] );
           a4 = 0.5*( ro[i][j] + ro[i][j-1] );


         if (i > 1)   ss -= theta*a2*c_new[i-1][j]/ht2;
            else      ss -= theta*a2*c_new[nxt][j]/ht2;
            
         if (i < nxt) ss -= theta*a1*c_new[i+1][j]/ht2;
           else        ss -=  theta*a1*c_new[1][j]/ht2;
            
            if (j > 1)  ss -= theta*a4*c_new[i][j-1]/ht2;
            else         ss -= theta*a4*c_new[i][nyt]/ht2;
            
            if (j < nyt) ss -=  theta*a3*c_new[i][j+1]/ht2;
            else        ss -=  theta*a3*c_new[i][1]/ht2;



        ru[i][j] = c_new[i][j]/dt - M1*lap_mu[i][j];
        rw[i][j] = mu_new[i][j] + lap_c[i][j] - alpha*lap_ka[i][j]
                    + theta*(a1 + a2 + a3 + a4)*c_new[i][j]/ht2 + ss;
        rk[i][j] = ka_new[i][j] -lap_c[i][j];

    }
    
    free_dmatrix(lap_c, 1, nxt, 1, nyt);
    free_dmatrix(lap_mu, 1, nxt, 1, nyt);
    free_dmatrix(lap_ka, 1, nxt, 1, nyt);
  
}

void restrict2(double **uf, double **uc, double **vf, double **vc, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        uc[i][j] = 0.25*(uf[2*i-1][2*j-1] + uf[2*i-1][2*j] + uf[2*i][2*j-1] + uf[2*i][2*j]);
        vc[i][j] = 0.25*(vf[2*i-1][2*j-1] + vf[2*i-1][2*j] + vf[2*i][2*j-1] + vf[2*i][2*j]);
    }
    
}


void restrict3(double **uf, double **uc, double **vf, double **vc, double **wf, double **wc, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        uc[i][j] = 0.25*(uf[2*i-1][2*j-1] + uf[2*i-1][2*j] + uf[2*i][2*j-1] + uf[2*i][2*j]);
        vc[i][j] = 0.25*(vf[2*i-1][2*j-1] + vf[2*i-1][2*j] + vf[2*i][2*j-1] + vf[2*i][2*j]);
        wc[i][j] = 0.25*(wf[2*i-1][2*j-1] + wf[2*i-1][2*j] + wf[2*i][2*j-1] + wf[2*i][2*j]);
    }
    
}


void restrict1(double **vf, double **vc, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        vc[i][j] = 0.25*(vf[2*i-1][2*j-1] + vf[2*i-1][2*j] + vf[2*i][2*j-1] + vf[2*i][2*j]);
    }
    
}

void prolong_ch(double **uc, double **uf, double **vc, double **vf, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        uf[2*i-1][2*j-1] = uf[2*i-1][2*j] = uf[2*i][2*j-1] = uf[2*i][2*j] = uc[i][j];
        vf[2*i-1][2*j-1] = vf[2*i-1][2*j] = vf[2*i][2*j-1] = vf[2*i][2*j] = vc[i][j];
    }
    
}


void prolong_ch3(double **uc, double **uf, double **vc, double **vf, double **wc, double **wf, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        uf[2*i-1][2*j-1] = uf[2*i-1][2*j] = uf[2*i][2*j-1] = uf[2*i][2*j] = uc[i][j];
        vf[2*i-1][2*j-1] = vf[2*i-1][2*j] = vf[2*i][2*j-1] = vf[2*i][2*j] = vc[i][j];
        wf[2*i-1][2*j-1] = wf[2*i-1][2*j] = wf[2*i][2*j-1] = wf[2*i][2*j] = wc[i][j];
    }
    
}

double error(double **c_old, double **c_new, int nxt, int nyt)
{
    double **r, res;
    
    r = dmatrix(1, nxt, 1, nyt);
    
    mat_sub(r, c_new, c_old, 1, nxt, 1, nyt);
    res = mat_max(r, 1, nxt, 1, nyt);
    
    free_dmatrix(r, 1, nxt, 1, nyt);
    
    return res;
}



/**********************************************/


double update_q(double **oc, double **c1, double **c2, int nxt, int nyt)
{
    extern double h, eta, ros;
    double t1, t2, t3, t4, t5, F, F2, res, tol, resid, nq, q;
    int i,j, kk = 1;

   t1 = 0.0; t2 = 0.0; t3 = 0.0; t4 = 0.0; t5 = 0.0;
   
   q = 1.0;

  tol = 1.0e-6;    resid = 1.0; 

   ijloopt{  

       t1 = t1 + h*h*pow(c2[i][j],4)/(4.0*eta*eta);
       t2 = t2 + h*h*( 4.0*c1[i][j]*pow(c2[i][j],3) - 2.0*ros*pow(c2[i][j],3) )/(4.0*eta*eta);
       t3 = t3 + h*h*( 6.0*pow(c1[i][j],2)*pow(c2[i][j],2) + ros*ros*pow(c2[i][j],2) - 2.0*ros*c1[i][j]*pow(c2[i][j],2) - 4.0*ros*c1[i][j]*pow(c2[i][j],2) )/(4.0*eta*eta)
                    - h*h*( c2[i][j]*oc[i][j]*(oc[i][j]-ros)*(oc[i][j]-0.5*ros)/(eta*eta) );
       t4 = t4 + h*h*( c2[i][j]*pow(c1[i][j],3) - ros*c2[i][j]*pow(c1[i][j],2) + c2[i][j]*pow(c1[i][j],3) + ros*ros*c1[i][j]*c2[i][j] + ros*c2[i][j]*pow(c1[i][j],2) )/(2.0*eta*eta)
                    - h*h*( (c1[i][j]-oc[i][j])*oc[i][j]*(oc[i][j]-ros)*(oc[i][j]-0.5*ros)/(eta*eta) );
       t5 = t5 + h*h*( pow(c1[i][j],4) + ros*pow(c1[i][j],2) - 2.0*ros*pow(c1[i][j],3) )/(4.0*eta*eta) - h*h*pow(oc[i][j],2)*pow(oc[i][j]-ros,2)/(4.0*eta*eta);
         
       }

    F = pow(q,4)*t1 + pow(q,3)*t2  + pow(q,2)*t3 + q*t4 + t5;
    F2 = 4.0*pow(q,3)*t1 + 3.0*pow(q,2)*t2 + 2.0*q*t3 + t4;

   while (kk <= 500 && resid > tol) {
        
       nq = q - F/F2;

       resid = fabs(nq-q);

       q = nq;
        
        kk++;
    }

   res = q;
      
    return res;
}

double update_r(double **oc, double **c1, double **c2, int nxt, int nyt)
{
    extern double h, gam;
    double t1, t2, t3, t4, t5, F, F2, res, tol, resid, nr, r;
    int i,j, kk = 1;

   t1 = 0.0; t2 = 0.0; t3 = 0.0; t4 = 0.0; t5 = 0.0;
   
   r = 1.0;

  tol = 1.0e-6;    resid = 1.0; 

   ijloopt{  

       t1 = t1 + h*h*pow(c2[i][j],4)/(4.0*gam*gam);
       t2 = t2 + h*h*( 4.0*c1[i][j]*pow(c2[i][j],3) )/(4.0*gam*gam);
       t3 = t3 + h*h*( 6.0*pow(c1[i][j],2)*pow(c2[i][j],2) - 2.0*pow(c2[i][j],2) )/(4.0*gam*gam)
                    - h*h*( c2[i][j]*(pow(oc[i][j],3)-oc[i][j])/(gam*gam) );
       t4 = t4 + h*h*( 4.0*pow(c1[i][j],3)*c2[i][j] - 4.0*c1[i][j]*c2[i][j] )/(4.0*gam*gam)
                    - h*h*( (c1[i][j]-oc[i][j])*(pow(oc[i][j],3)-oc[i][j])/(gam*gam) );
       t5 = t5 + h*h*( pow(c1[i][j],4) + 2.0*pow(c1[i][j],2) + 1.0 )/(4.0*gam*gam) - h*h*pow(oc[i][j]*oc[i][j]-1.0,2)/(4.0*gam*gam);
         
       }

    F = pow(r,4)*t1 + pow(r,3)*t2  + pow(r,2)*t3 + r*t4 + t5;
    F2 = 4.0*pow(r,3)*t1 + 3.0*pow(r,2)*t2 + 2.0*r*t3 + t4;

   while (kk <= 500 && resid > tol) {
        
       nr = r - F/F2;

       resid = fabs(nr-r);

       r = nr;
        
        kk++;
    }

   res = r;
      
    return res;
}


/*************** util ****************/
double **dmatrix(long nrl, long nrh, long ncl, long nch)
{
    double **m;
    long i, nrow=nrh-nrl+1+NR_END, ncol=nch-ncl+1+NR_END;
    
    m=(double **) malloc((nrow)*sizeof(double*));
    m+=NR_END;
    m-=nrl;
    
    m[nrl]=(double *) malloc((nrow*ncol)*sizeof(double));
    m[nrl]+=NR_END;
    m[nrl]-=ncl;
    
    for (i=nrl+1; i<=nrh; i++) m[i]=m[i-1]+ncol;
    
    return m;
}

void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch)
{
    free(m[nrl]+ncl-NR_END);
    free(m+nrl-NR_END);
    
    return;
}

void zero_matrix(double **a, int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = 0.0;
        }
    }
    
    return;
}

void mat_copy(double **a, double **b, int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j];
        }
    }
    
    return;
}

void mat_copy2(double **a, double **b, double **a2, double **b2,
               int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j];
            a2[i][j] = b2[i][j];
        }
    }
    
    return;
}

void mat_add(double **a, double **b, double **c,
             int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j]+c[i][j];
        }
    }
    
    return;
}

void mat_add2(double **a, double **b, double **c,
              double **a2, double **b2, double **c2,
              int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j]+c[i][j];
            a2[i][j] = b2[i][j]+c2[i][j];
        }
    }
    
    return;
}


void mat_add3(double **a, double **b, double **c,
              double **a2, double **b2, double **c2,
              double **a3, double **b3, double **c3,
              int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j]+c[i][j];
            a2[i][j] = b2[i][j]+c2[i][j];
            a3[i][j] = b3[i][j]+c3[i][j];
        }
    }
    
    return;
}

void mat_sub(double **a, double **b, double **c,
             int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            a[i][j] = b[i][j]-c[i][j];
        }
    }
    
    return;
}

void mat_sub2(double **a, double **b, double **c,
              double **a2, double **b2, double **c2,
              int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            a[i][j] = b[i][j]-c[i][j];
            a2[i][j] = b2[i][j]-c2[i][j];
        }
    }
    
    return;
}


void mat_sub3(double **a, double **b, double **c,
              double **a2, double **b2, double **c2,
              double **a3, double **b3, double **c3,
              int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            a[i][j] = b[i][j]-c[i][j];
            a2[i][j] = b2[i][j]-c2[i][j];
            a3[i][j] = b3[i][j]-c3[i][j];
        }
    }
    
    return;
}

double mat_max(double **a, int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    double x = 0.0;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            if (fabs(a[i][j]) > x)
                x = fabs(a[i][j]);
        }
    }
    
    return x;
}


void print_mat(FILE *fptr, double **a, int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++)
            fprintf(fptr, "   %16.14f", a[i][j]);
        
        fprintf(fptr, "\n");
    }
    
    return;
}


void print_data(double **c, double **ro)
{
    extern char bufferc[100], bufferro[100];
    int i, j;
   FILE *fc, *fro;
 
    fc = fopen(bufferc,"a");
    fro = fopen(bufferro,"a");

   iloop {
        jloop {
 		  
           fprintf(fc, "  %16.14f", c[i][j]);
           fprintf(fro, "  %16.14f", ro[i][j]);

	   }

                   fprintf(fc, "\n");
                   fprintf(fro, "\n");
    }
   
    fclose(fc);
    fclose(fro);

  return;
}



