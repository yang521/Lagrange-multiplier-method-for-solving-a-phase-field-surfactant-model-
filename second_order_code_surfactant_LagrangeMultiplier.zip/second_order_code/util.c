#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include "util.h"
#include "bnsch.h"


#define NR_END 1

double **dmatrix(long nrl, long nrh, long ncl, long nch)
{
    double **m;
    long i, nrow=nrh-nrl+1+NR_END, ncol=nch-ncl+1+NR_END;
    
    m=(double **) malloc((nrow)*sizeof(double*));
    m+=NR_END;
    m-=nrl;
    
    m[nrl]=(double *) malloc((nrow*ncol)*sizeof(double));
    m[nrl]+=NR_END;
    m[nrl]-=ncl;
    
    for (i=nrl+1; i<=nrh; i++) m[i]=m[i-1]+ncol;
    
    return m;
}

void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch)
{
    free(m[nrl]+ncl-NR_END);
    free(m+nrl-NR_END);
    
    return;
}

void zero_matrix(double **a, int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = 0.0;
        }
    }
    
    return;
}

void mat_copy(double **a, double **b, int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j];
        }
    }
    
    return;
}

void mat_copy2(double **a, double **b, double **a2, double **b2,
               int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j];
            a2[i][j] = b2[i][j];
        }
    }
    
    return;
}

void mat_add(double **a, double **b, double **c,
             int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j]+c[i][j];
        }
    }
    
    return;
}

void mat_add2(double **a, double **b, double **c,
              double **a2, double **b2, double **c2,
              int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j]+c[i][j];
            a2[i][j] = b2[i][j]+c2[i][j];
        }
    }
    
    return;
}

void mat_sub(double **a, double **b, double **c,
             int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            a[i][j] = b[i][j]-c[i][j];
        }
    }
    
    return;
}

void mat_sub2(double **a, double **b, double **c,
              double **a2, double **b2, double **c2,
              int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            a[i][j] = b[i][j]-c[i][j];
            a2[i][j] = b2[i][j]-c2[i][j];
        }
    }
    
    return;
}

double mat_max(double **a, int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    double x = 0.0;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            if (fabs(a[i][j]) > x)
                x = fabs(a[i][j]);
        }
    }
    
    return x;
}


void print_mat(FILE *fptr, double **a, int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++)
            fprintf(fptr, "   %16.14f", a[i][j]);
        
        fprintf(fptr, "\n");
    }
    
    return;
}

void print_data(double **c)
{
    extern int nx, ny, count;
    
    char bufferc[100];
    FILE  *fp;
    
    
    sprintf(bufferc,"data/c%d.m",count);
    fc=fopen(bufferc,"w");
  
    
  
    print_mat(fc,c,1,nx,1,ny);
   
    
  
    fclose(fc);

    
    return;
}



